﻿minivibe mac 0.4.2 (osx-arm64)

Fast start:
1. Unzip this archive.
2. Double-click Run-Minivibe.command.

Terminal start from any folder:
cd "/path/to/unzipped/minivibe"
chmod +x ./Run-Minivibe.command ./MinivibeMac
./Run-Minivibe.command

The launcher is self-contained and does not require installing .NET separately.
